//
// Created by prachu on 5/9/20.
//

#pragma once

namespace fp {
    class algorithm {

    };
}


